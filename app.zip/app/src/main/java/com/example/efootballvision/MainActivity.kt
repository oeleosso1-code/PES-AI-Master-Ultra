package com.example.efootballvision

import android.app.Activity
import android.app.Activity.RESULT_OK
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.example.efootballvision.capture.ScreenCaptureService
import com.example.efootballvision.overlay.FloatingOverlayService

class MainActivity : Activity() {
    private val captureRequest = 1001
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30, 50, 30, 30) }
        layout.addView(TextView(this).apply { text = "EFootball Vision: screen-analysis prototype. No automated gameplay controls." })
        layout.addView(Button(this).apply { text = "Allow screen capture"; setOnClickListener {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
        } })
        layout.addView(Button(this).apply { text = "Show analytics overlay"; setOnClickListener {
            if (!Settings.canDrawOverlays(this@MainActivity)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else startService(Intent(this@MainActivity, FloatingOverlayService::class.java))
        } })
        layout.addView(Button(this).apply { text = "Stop capture"; setOnClickListener { stopService(Intent(this@MainActivity, ScreenCaptureService::class.java)) } })
        setContentView(layout)
    }
    @Deprecated("Uses the Activity result API for compatibility with this minimal sample")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            })
        }
    }
}
