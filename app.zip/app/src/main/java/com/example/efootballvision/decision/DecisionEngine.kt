package com.example.efootballvision.decision

/** Advisory-only decision tree. No game actions are executed. */
data class WorldState(
    val hasPossession: Boolean,
    val ballInDefensiveThird: Boolean,
    val passingLaneOpen: Boolean,
    val shotLaneOpen: Boolean,
    val minute: Int,
    val scoreDifference: Int,
    val lowestStamina: Float?,
    val confidence: Float
)
enum class TacticalMode { BALANCED, ATTACKING, DEFENSIVE }
data class Advice(val action: String, val explanation: String, val suggestSubstitution: Boolean)
private sealed interface Node { fun evaluate(state: WorldState): Advice? }
private class Condition(private val predicate: (WorldState) -> Boolean, private val child: Node) : Node {
    override fun evaluate(state: WorldState): Advice? = if (predicate(state)) child.evaluate(state) else null
}
private class Leaf(private val action: String, private val explanation: String) : Node {
    override fun evaluate(state: WorldState): Advice = Advice(action, explanation, false)
}
private class Selector(private val nodes: List<Node>) : Node {
    override fun evaluate(state: WorldState): Advice? = nodes.firstNotNullOfOrNull { it.evaluate(state) }
}
class DecisionEngine {
    private val root = Selector(listOf(
        Condition({ it.confidence < 0.5f }, Leaf("OBSERVE", "Vision confidence is insufficient")),
        Condition({ !it.hasPossession && it.ballInDefensiveThird }, Leaf("DEFEND", "Protect the central passing lane")),
        Condition({ it.hasPossession && it.shotLaneOpen }, Leaf("CONSIDER_SHOT", "Open shooting lane")),
        Condition({ it.hasPossession && it.passingLaneOpen }, Leaf("CONSIDER_PASS", "Passing lane available")),
        Leaf("HOLD_SHAPE", "Maintain team shape")
    ))
    fun evaluate(state: WorldState, mode: TacticalMode): Advice {
        val base = requireNotNull(root.evaluate(state))
        val substitution = state.minute >= 60 && (state.lowestStamina ?: 1f) < 0.3f
        val context = when {
            state.scoreDifference < 0 && state.minute >= 75 -> "Late deficit: review attacking shape"
            state.scoreDifference > 0 && state.minute >= 80 -> "Late lead: review defensive shape"
            else -> "Selected mode: $mode"
        }
        return base.copy(explanation = "${base.explanation}. $context", suggestSubstitution = substitution)
    }
}
