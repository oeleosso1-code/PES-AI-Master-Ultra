package com.example.efootballvision.inference

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.nio.FloatBuffer

/** Generic NCHW inference. Output parsing must match the actual exported model's metadata. */
class OnnxInferenceHelper(modelBytes: ByteArray) : AutoCloseable {
    private val environment = OrtEnvironment.getEnvironment()
    private val session: OrtSession = environment.createSession(modelBytes, OrtSession.SessionOptions())
    private val inputName: String = session.inputNames.first()
    fun run(input: FloatArray, width: Int, height: Int): Array<FloatArray> {
        require(input.size == 3 * width * height) { "Expected RGB NCHW tensor" }
        OnnxTensor.createTensor(environment, FloatBuffer.wrap(input), longArrayOf(1, 3, height.toLong(), width.toLong())).use { tensor ->
            session.run(mapOf(inputName to tensor)).use { results ->
                return results.mapNotNull { result ->
                    when (val value = result.value) {
                        is Array<*> -> flattenNumeric(value)
                        else -> null
                    }
                }.toTypedArray()
            }
        }
    }
    private fun flattenNumeric(value: Any?): FloatArray? {
        val output = ArrayList<Float>()
        fun visit(item: Any?) {
            when (item) {
                is FloatArray -> item.forEach { output.add(it) }
                is Array<*> -> item.forEach { visit(it) }
                is Number -> output.add(item.toFloat())
            }
        }
        visit(value)
        return if (output.isEmpty()) null else output.toFloatArray()
    }
    override fun close() { session.close() }
}
