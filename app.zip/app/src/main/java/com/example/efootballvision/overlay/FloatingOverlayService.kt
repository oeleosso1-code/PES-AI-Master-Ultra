package com.example.efootballvision.overlay

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.example.efootballvision.decision.TacticalMode

class FloatingOverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var overlay: LinearLayout? = null
    private var mode = TacticalMode.BALANCED
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (overlay != null || !Settings.canDrawOverlays(this)) return START_NOT_STICKY
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16); setBackgroundColor(0xDD202830.toInt()) }
        val status = TextView(this).apply { setTextColor(-1); text = "Vision dashboard • $mode\nStats unavailable until model is configured" }
        panel.addView(status)
        panel.addView(Button(this).apply { text = "Switch tactics"; setOnClickListener {
            mode = when (mode) { TacticalMode.BALANCED -> TacticalMode.ATTACKING; TacticalMode.ATTACKING -> TacticalMode.DEFENSIVE; TacticalMode.DEFENSIVE -> TacticalMode.BALANCED }
            status.text = "Vision dashboard • $mode\nStats unavailable until model is configured"
        } })
        panel.addView(Button(this).apply { text = "Close"; setOnClickListener { stopSelf() } })
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 120 }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager!!.addView(panel, params)
        overlay = panel
        return START_NOT_STICKY
    }
    override fun onDestroy() { overlay?.let { windowManager?.removeView(it) }; overlay = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
