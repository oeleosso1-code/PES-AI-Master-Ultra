package com.example.efootballvision.touch

import kotlin.math.pow

/** Geometry-only path generator for visual calibration and testing; it does not inject touch events. */
class TouchInjector {
    data class Point(val x: Float, val y: Float)
    fun normalizedToPixels(point: Point, width: Int, height: Int): Point {
        require(width > 0 && height > 0)
        return Point(point.x.coerceIn(0f, 1f) * width, point.y.coerceIn(0f, 1f) * height)
    }
    fun cubicBezier(start: Point, controlA: Point, controlB: Point, end: Point, steps: Int): List<Point> {
        require(steps > 0)
        return (0..steps).map { index ->
            val t = index.toFloat() / steps
            val u = 1f - t
            val a = u.pow(3)
            val b = 3f * u.pow(2) * t
            val c = 3f * u * t.pow(2)
            val d = t.pow(3)
            Point(a * start.x + b * controlA.x + c * controlB.x + d * end.x,
                a * start.y + b * controlA.y + c * controlB.y + d * end.y)
        }
    }
}
